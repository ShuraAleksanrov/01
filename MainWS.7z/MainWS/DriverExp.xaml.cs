﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;
using System.Diagnostics;
namespace MainWS
{
    /// <summary>
    /// Логика взаимодействия для DriverExp.xaml
    /// </summary>
    public partial class DriverExp : Window
    {
        DataTable table = new DataTable();
        MySqlConnection connection;
        public DriverExp()
        {
            InitializeComponent();
        }

        private void EditDriver_Click(object sender, RoutedEventArgs e)
        {
            if(DriverDG.SelectedIndex != -1)
            {
                int i = DriverDG.SelectedIndex;
                EditDriver win = new EditDriver();
                win.dataRow = DriverDG.SelectedItem as DataRowView;
                win.Show();
                this.Close();
            }else
            {
                MessageBox.Show("Не выбран водитель!");
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        

        private void Window_Closed(object sender, EventArgs e)
        {
            connection.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            connection = new MySqlConnection("server = localhost; database = ws; user = root; password = root;");
            connection.Open();
            MySqlCommand command = new MySqlCommand("select * from driver;", connection);
            MySqlDataReader reader = command.ExecuteReader();            
            table.Load(reader);
            table.Columns.Add("image");
            int i = 0; int q = table.Rows.Count;
            for (;i<q;i++) {
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                image.UriSource = new Uri(Environment.CurrentDirectory + @"\img\" + table.Rows[i]["img"]);
                image.EndInit();
                table.Rows[i]["image"] = image;
            }
            DriverDG.ItemsSource = table.DefaultView;
            reader.Close();
        }

        private void LicOpen_Click(object sender, RoutedEventArgs e)
        {
            if (DriverDG.SelectedIndex != -1)
            {
                LicDIalog win = new LicDIalog();
                win.row = DriverDG.SelectedItem as DataRowView;
            }
            else
            {
                MessageBox.Show("Не выбран водитель!");
            }
            
        }
    }
}
