﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using System.Data;
namespace MainWS
{
    /// <summary>
    /// Логика взаимодействия для LicDIalog.xaml
    /// </summary>
    public partial class LicDIalog : Window
    {
        public DataRowView row;
        MySqlConnection connection;
        public LicDIalog()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            connection = new MySqlConnection("server = localhost; database = ws; user = root; password = root;");
            connection.Open();
            MySqlCommand command = new MySqlCommand("select * from lic where fk='" + row["id"].ToString() + "';", connection);
            MySqlDataReader read = command.ExecuteReader();
            if (read.Read())
            {

            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {

        }
    }
}
